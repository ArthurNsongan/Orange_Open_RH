export default {
    "app": {
        "name": "Challenge Solidarité",
        "logo": "",
        "url": ""
    }
}