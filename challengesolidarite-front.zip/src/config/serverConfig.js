const server = {
    // "apiAddress": "http://172.21.75.119:8001"
    "apiAddress": "http://172.21.170.21:8000"
    // "apiAddress": "http://127.0.0.1:8000"
}

export default server;