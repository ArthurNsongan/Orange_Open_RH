const server = {
    "apiAddress": "http://172.21.75.119:8000"
}

export default server;