import React from 'react'

function AuthLayout() {
    return (
        <div>
            <h1>Authentication</h1>
        </div>
    )
}

export default AuthLayout